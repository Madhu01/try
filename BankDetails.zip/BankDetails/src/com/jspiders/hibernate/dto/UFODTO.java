package com.jspiders.hibernate.dto;

//import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bank")
public class UFODTO {// implements Serializable {

	public UFODTO() 
	{
		System.out.println(this.getClass().getSimpleName() + " created");
	}

	@Id
	@Column(name = "empid")
	private int empID;
	@Column(name = "account_number")
	private int acc;
	@Column(name = "name")
	private String name;
	@Column(name = "balance")
	private double balance;
	@Column(name = "phone_number")
	private String phoneno;
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public int getAcc() {
		return acc;
	}
	public void setAcc(int acc) {
		this.acc = acc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	
	
}
