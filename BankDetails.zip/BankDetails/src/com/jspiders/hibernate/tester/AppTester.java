package com.jspiders.hibernate.tester;
import java .util.*;
import com.jspiders.hibernate.dao.UFODAO;
import com.jspiders.hibernate.dto.UFODTO;
/*wap to enter a employee bank details into a bank table.
the data should be entered dynamically using scanner class.*/
public class AppTester {

	public static void main(String[] args) {
		int empid,acc,balance;
		String name,phone;
		UFODTO dto = new UFODTO();
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter your Employee ID: ");
		empid=sc.nextInt();
		System.out.println("Enter your Account Number : ");
		acc=sc.nextInt();
		System.out.println("Enter your Name: ");
		name=sc.next();
		System.out.println("Enter your Balance: ");
		balance=sc.nextInt();
		System.out.println("Enter your Phone number: ");
		phone=sc.next();
		
		dto.setEmpID(empid);
        
		dto.setAcc(acc);
		dto.setName(name);
		dto.setBalance(balance);
		dto.setPhoneno(phone);
		System.out.println(dto);
		
		UFODAO dao = new UFODAO();
		dao.saveUFO(dto);
		
	}

}
